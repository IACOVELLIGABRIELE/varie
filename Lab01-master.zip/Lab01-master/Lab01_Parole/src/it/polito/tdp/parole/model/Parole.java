package it.polito.tdp.parole.model;

import java.util.List;

public class Parole {
		
	public Parole() {
		//TODO
	}
	
	public void addParola(String p) {
		//TODO
	}
	
	public List<String> getElenco() {
		//TODO
		return null;
	}
	
	public void reset() {
		// TODO
	}

}
